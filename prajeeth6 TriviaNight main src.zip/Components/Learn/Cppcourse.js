import React from 'react'

const Cppcourse = () => {
  return (
    <div>Cppcourse</div>
  )
}

export default Cppcourse