import React from 'react'

const Javacourse = () => {
  return (
    <div>Javacourse</div>
  )
}

export default Javacourse